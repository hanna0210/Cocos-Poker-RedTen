var hongshi = {
    serverAddress: "ws://101.37.19.68:8011",
    userData: {},
};

module.exports = hongshi;