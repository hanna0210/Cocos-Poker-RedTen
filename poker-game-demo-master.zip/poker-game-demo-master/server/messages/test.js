var test= new Object();
test.getReply = function (id, data, callBack) {
    var resData = null;
    console.log('test:\n' + JSON.stringify(data) + '\n\n\n\n\n');
};
module.exports = test;