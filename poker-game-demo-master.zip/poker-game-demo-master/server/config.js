module.exports = {
    normal_server: {
		address: 'localhost',
		port: 8011,
	},
	game_server: {
		address: 'localhost',
		port: 8012,
	},
    mysql: {
        host: "localhost",
        port: 3306,
        user: "root",
        password: "password",
        database: "hongshi",
    },
	
};