var hongshi = {
    serverAddress: "ws://localhost:8011",
};

module.exports = hongshi;